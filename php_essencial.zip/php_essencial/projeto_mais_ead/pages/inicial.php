<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Página Inicial</h5>
                    <span>Seja bem vindo a THE NEW SCHOOL</span>
                </div>
                <div class="card-block">
                    <p>
                        Na THE NEW SCHOOL nós ensinamos vários cursos muito interessantes para você de forma acessível, prática e simples.
                    </p>
                    <p><a href="index.php?p=loja_cursos">Clique aqui</a> para conhecer os nossos cursos.</p>
                </div>
            </div>
        </div>
    </div>
</div>